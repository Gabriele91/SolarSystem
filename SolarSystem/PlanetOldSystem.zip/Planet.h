#ifndef PLANET_H
#define PLANET_H

#include <Config.h>
#include <Utility.h>
#include <Object.h>
#include <Texture.h>
#include <Camera.h>

namespace SolarSystem {

	class Planet : public Object {
		
		/**
			http://www.stjarnhimlen.se/comp/ppcomp.html
		    N = longitude of the ascending node
			i = inclination to the ecliptic (plane of the Earth's orbit)
			w = argument of perihelion
			a = semi-major axis, or mean distance from Sun
			e = eccentricity (0=circle, 0-1=ellipse, 1=parabola)
			M = mean anomaly (0 at perihelion; increases uniformly with time)
		
		Mean Anomaly (M): 
			This angle increases uniformly over time, by 360 degrees per orbital period. 
			It's zero at perihelion. 
			It's easily computed from the orbital period and the time since last perihelion.

		True Anomaly (v): 
			This is the actual angle between the planet and the perihelion, as seen from the central body (in this case the Sun). 
			It increases non-uniformly with time, changing most rapidly at perihelion.

		Eccentric Anomaly (E): 
			This is an auxiliary angle used in Kepler's Equation, 
			when computing the True Anomaly from the Mean Anomaly and the orbital eccentricity.


		Note that for a circular orbit (eccentricity=0), these three angles are all equal to each other.

		    (y=year, m=month, D=date, UT=UT in hours+decimals)

			d = 367*y - 7 * ( y + (m+9)/12 ) / 4 + 275*m/9 + D - 730530

			Note that ALL divisions here should be INTEGER divisions. 

			Orbital elements of the Sun:
				N = 0.0
				i = 0.0
				w = 282.9404 + 4.70935E-5 * d
				a = 1.000000  (AU)
				e = 0.016709 - 1.151E-9 * d
				M = 356.0470 + 0.9856002585 * d

			Orbital elements of the Moon:
				N = 125.1228 - 0.0529538083 * d
				i = 5.1454
				w = 318.0634 + 0.1643573223 * d
				a = 60.2666  (Earth radii)
				e = 0.054900
				M = 115.3654 + 13.0649929509 * d

			Orbital elements of Mercury:
				N =  48.3313 + 3.24587E-5 * d
				i = 7.0047 + 5.00E-8 * d
				w =  29.1241 + 1.01444E-5 * d
				a = 0.387098  (AU)
				e = 0.205635 + 5.59E-10 * d
				M = 168.6562 + 4.0923344368 * d

			Orbital elements of Venus:
				N =  76.6799 + 2.46590E-5 * d
				i = 3.3946 + 2.75E-8 * d
				w =  54.8910 + 1.38374E-5 * d
				a = 0.723330  (AU)
				e = 0.006773 - 1.302E-9 * d
				M =  48.0052 + 1.6021302244 * d

			Orbital elements of Mars:
				N =  49.5574 + 2.11081E-5 * d
				i = 1.8497 - 1.78E-8 * d
				w = 286.5016 + 2.92961E-5 * d
				a = 1.523688  (AU)
				e = 0.093405 + 2.516E-9 * d
				M =  18.6021 + 0.5240207766 * d

			Orbital elements of Jupiter:
				N = 100.4542 + 2.76854E-5 * d
				i = 1.3030 - 1.557E-7 * d
				w = 273.8777 + 1.64505E-5 * d
				a = 5.20256  (AU)
				e = 0.048498 + 4.469E-9 * d
				M =  19.8950 + 0.0830853001 * d

			Orbital elements of Saturn:
				N = 113.6634 + 2.38980E-5 * d
				i = 2.4886 - 1.081E-7 * d
				w = 339.3939 + 2.97661E-5 * d
				a = 9.55475  (AU)
				e = 0.055546 - 9.499E-9 * d
				M = 316.9670 + 0.0334442282 * d

			Orbital elements of Uranus:
				N =  74.0005 + 1.3978E-5 * d
				i = 0.7733 + 1.9E-8 * d
				w =  96.6612 + 3.0565E-5 * d
				a = 19.18171 - 1.55E-8 * d  (AU)
				e = 0.047318 + 7.45E-9 * d
				M = 142.5905 + 0.011725806 * d

			Orbital elements of Neptune:
				N = 131.7806 + 3.0173E-5 * d
				i = 1.7700 - 2.55E-7 * d
				w = 272.8461 - 6.027E-6 * d
				a = 30.05826 + 3.313E-8 * d  (AU)
				e = 0.008606 + 2.15E-9 * d
				M = 260.2471 + 0.005995147 * d
		*/

	public:

		struct PlanetInfo{
			float	N,
					i,
					w,
					a,
					e,
					M;
			PlanetInfo(
				      float N=0,
				      float i=0,
					  float w=0,
					  float a=0,
					  float e=0,
					  float M=0)
					 :N(N),i(i),w(w),a(a),e(e),M(M){}
			PlanetInfo operator*(float d){
				return PlanetInfo(N*d,i*d,w*d,a*d,e*d,M*d);
			}
			PlanetInfo operator+(const PlanetInfo& inf){
				return PlanetInfo(N+inf.N,i+inf.i,w+inf.w,a+inf.a,e+inf.e,M+inf.M);
			}
		};
	
	private:
		//gpu buffers
		struct GLVertex{
			Vec3 vertices;
			Vec3 normals;
			Vec2 texcoords;
		};
		//
		uint verticesSize;
		uint verticesBuffer;
		//
		uint indicesSize;
		uint indicesBuffer;
		//
		void buildMesh(int rings,int sectors);
		//texture
		Texture texture;
		//planet values		
		PlanetInfo infoBase,
				   infoMuld;
		//current value
		struct InfoCalc{
			int curDayNumber;
			PlanetInfo info;
			float E,r,v;
		}vlsCalc;

		//the date is expressed in day function
		void calcDayNumber(int year,int month,int day,int hours,int mins){
			float UT = ((float)hours + (float)mins/60.0f)/24.0f;
			int dayNm= 367*year - 7 * ( year + (month+9)/12 ) / 4 + 275*month/9 + day - 730530;
			vlsCalc.curDayNumber=(dayNm+UT);
			vlsCalc.info=infoBase+infoMuld*vlsCalc.curDayNumber;
		}
		void calcERV(){
			vlsCalc.E= 
				vlsCalc.info.M + 
				vlsCalc.info.e *  
				std::sin(vlsCalc.info.M) * 
				( 1.0 + vlsCalc.info.e * std::cos(vlsCalc.info.M) );

			float xv = std::cos(vlsCalc.E) - vlsCalc.info.e;
			float yv = std::sqrt(1.0 - vlsCalc.info.e*vlsCalc.info.e) * std::sin(vlsCalc.E);
			vlsCalc.v = std::atan2( yv, xv );
			vlsCalc.r = std::sqrt( xv*xv + yv*yv );
		}
		Vec3 calc3DCordinate(){
			Vec3 h;
			float cosN=std::cos(vlsCalc.info.N) ;
			float sinN=std::sin(vlsCalc.info.N) ;
			float cosVW=std::cos(vlsCalc.v+vlsCalc.info.w) ;
			float sinVW=std::sin(vlsCalc.v+vlsCalc.info.w) ;
			float cosI=std::cos(vlsCalc.info.i) ;

			h.x = vlsCalc.r * ( cosN  *  cosVW - sinN * sinVW * cosI );
			h.y = vlsCalc.r * ( sinN  *  cosVW + cosN * sinVW * cosI );
			h.z = vlsCalc.r * ( sinVW *  sin(vlsCalc.info.i) );
			return h;
		}

	public:
		/**
		*
		* Plane Costructor 
		*
		* @param texture (path texture)
		* @param fsun (Ellipse focus sun)
		* @param f2 (Ellipse focus2)
		* @param deysRevolution=365.25636f (revolution period in days)
		* @param rotationPeriod=24.0f (rotation period in hours)
		* @param rings=50 (number of rings)
		* @param sectors=50 (number of sectors)
		*
		*/
		Planet(const Utility::Path& texture,
			   int rings=50,
			   int sectors=50);
		//draw
		void draw(Camera& camera);
		//set time
		void setDataTime(int year,int month,int day,int hours,int mins);
		//set planet info
		void setPlanetInfo(const PlanetInfo& base,const PlanetInfo& muld){
			infoBase=base;
			infoMuld=muld;
		}
	};

};

#endif